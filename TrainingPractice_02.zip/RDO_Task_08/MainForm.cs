﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RDO_Task_08
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        //Открытие формы с правилами и сведениями об игре
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInfo formInfo = new FormInfo();
            formInfo.Show();
        }

        //Кнопка, отвечающая за выход из приложения
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Открытие формы с авторизацией
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginForm loginform = new loginForm();
            loginform.Show();
        }

        //Открытие формы с таблицами результатов
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            results results = new results();
            results.Show();
        }
    }
}
