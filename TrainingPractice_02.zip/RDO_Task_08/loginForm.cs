﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RDO_Task_08
{
    public partial class loginForm : Form
    {
        public loginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (namebox.Text != "")         //Если в namebox.Text присвоено значение
            {
                //Запись логина в файл
                TextWriter sw = new StreamWriter("name.txt" , true);
                sw.WriteLine(namebox.Text);
                sw.Close();

                //Открытие PlayForm
                this.Hide();
                PlayForm playForm = new PlayForm();
                playForm.Show();
            }
            else                            //Если в namebox.Text не присвоено значение(т.е. namebox пустой) 
            {
                MessageBox.Show("Введите имя пользователя!");
            }

        }
    }
}
