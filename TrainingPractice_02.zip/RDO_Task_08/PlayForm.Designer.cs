﻿namespace RDO_Task_08
{
    partial class PlayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.glavnoeMenu = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // glavnoeMenu
            // 
            this.glavnoeMenu.Location = new System.Drawing.Point(12, 406);
            this.glavnoeMenu.Name = "glavnoeMenu";
            this.glavnoeMenu.Size = new System.Drawing.Size(114, 32);
            this.glavnoeMenu.TabIndex = 0;
            this.glavnoeMenu.Text = "Вернуться назад";
            this.glavnoeMenu.UseVisualStyleBackColor = true;
            this.glavnoeMenu.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = global::RDO_Task_08.Properties.Resources.image__7_;
            this.pictureBox1.Location = new System.Drawing.Point(146, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(642, 426);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.Location = new System.Drawing.Point(763, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(15, 15);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(732, 26);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(15, 15);
            this.button2.TabIndex = 3;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(646, 26);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(15, 15);
            this.button3.TabIndex = 4;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(595, 26);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(15, 15);
            this.button4.TabIndex = 5;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(513, 26);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(15, 15);
            this.button5.TabIndex = 6;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(492, 26);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(15, 15);
            this.button6.TabIndex = 7;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(393, 26);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(15, 15);
            this.button7.TabIndex = 8;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(356, 26);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(15, 15);
            this.button8.TabIndex = 9;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(209, 25);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(15, 15);
            this.button9.TabIndex = 10;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(172, 23);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(15, 15);
            this.button10.TabIndex = 11;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Visible = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(155, 44);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(15, 15);
            this.button11.TabIndex = 12;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Visible = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(170, 64);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(15, 15);
            this.button12.TabIndex = 13;
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Visible = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(277, 65);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(15, 15);
            this.button13.TabIndex = 14;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Visible = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(315, 65);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(15, 15);
            this.button14.TabIndex = 15;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Visible = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(432, 65);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(15, 15);
            this.button15.TabIndex = 16;
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Visible = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(465, 65);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(15, 15);
            this.button16.TabIndex = 17;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Visible = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(606, 65);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(15, 15);
            this.button17.TabIndex = 18;
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Visible = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(670, 65);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(15, 15);
            this.button18.TabIndex = 19;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Visible = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(735, 65);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(15, 15);
            this.button19.TabIndex = 20;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Visible = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(763, 84);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(15, 15);
            this.button20.TabIndex = 21;
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Visible = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(750, 109);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(15, 15);
            this.button21.TabIndex = 22;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Visible = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(704, 109);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(15, 15);
            this.button22.TabIndex = 23;
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Visible = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(636, 109);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(15, 15);
            this.button23.TabIndex = 24;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Visible = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(516, 108);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(15, 15);
            this.button24.TabIndex = 25;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Visible = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(496, 108);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(15, 15);
            this.button25.TabIndex = 26;
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Visible = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(449, 109);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(15, 15);
            this.button26.TabIndex = 27;
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Visible = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(380, 108);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(15, 15);
            this.button27.TabIndex = 28;
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Visible = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(212, 108);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(15, 15);
            this.button28.TabIndex = 29;
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Visible = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(180, 109);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(15, 15);
            this.button29.TabIndex = 30;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Visible = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(159, 118);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(15, 15);
            this.button30.TabIndex = 31;
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Visible = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(159, 139);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(15, 15);
            this.button31.TabIndex = 32;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Visible = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(183, 150);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(15, 15);
            this.button32.TabIndex = 33;
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Visible = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(212, 151);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(15, 15);
            this.button33.TabIndex = 34;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Visible = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(394, 152);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(15, 15);
            this.button34.TabIndex = 35;
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Visible = false;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(419, 152);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(15, 15);
            this.button35.TabIndex = 36;
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Visible = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(460, 153);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(15, 15);
            this.button36.TabIndex = 37;
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Visible = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(554, 153);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(15, 15);
            this.button37.TabIndex = 38;
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Visible = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(666, 153);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(15, 15);
            this.button38.TabIndex = 39;
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Visible = false;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(735, 155);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(15, 15);
            this.button39.TabIndex = 40;
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Visible = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(763, 179);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(15, 15);
            this.button40.TabIndex = 41;
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Visible = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(745, 198);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(15, 15);
            this.button41.TabIndex = 42;
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Visible = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(696, 195);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(15, 15);
            this.button42.TabIndex = 43;
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Visible = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(617, 197);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(15, 15);
            this.button43.TabIndex = 44;
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Visible = false;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(467, 197);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(15, 15);
            this.button44.TabIndex = 45;
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Visible = false;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(430, 195);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(15, 15);
            this.button45.TabIndex = 46;
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Visible = false;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(409, 196);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(15, 15);
            this.button46.TabIndex = 47;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Visible = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(349, 196);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(15, 15);
            this.button47.TabIndex = 48;
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Visible = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(270, 195);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(15, 15);
            this.button48.TabIndex = 49;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Visible = false;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(194, 194);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(15, 15);
            this.button49.TabIndex = 50;
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Visible = false;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(170, 195);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(15, 15);
            this.button50.TabIndex = 51;
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Visible = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(156, 223);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(15, 15);
            this.button51.TabIndex = 52;
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Visible = false;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(233, 237);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(15, 15);
            this.button52.TabIndex = 53;
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Visible = false;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(337, 237);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(15, 15);
            this.button53.TabIndex = 54;
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Visible = false;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(362, 237);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(15, 15);
            this.button54.TabIndex = 55;
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Visible = false;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(398, 237);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(15, 15);
            this.button55.TabIndex = 56;
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Visible = false;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(499, 237);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(15, 15);
            this.button56.TabIndex = 57;
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Visible = false;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(560, 238);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(15, 15);
            this.button57.TabIndex = 58;
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Visible = false;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(576, 238);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(15, 15);
            this.button58.TabIndex = 59;
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Visible = false;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(687, 238);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(15, 15);
            this.button59.TabIndex = 60;
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Visible = false;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(745, 238);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(15, 15);
            this.button60.TabIndex = 61;
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Visible = false;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(760, 262);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(15, 15);
            this.button61.TabIndex = 62;
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Visible = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(741, 282);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(15, 15);
            this.button62.TabIndex = 63;
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Visible = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(645, 283);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(15, 15);
            this.button63.TabIndex = 64;
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Visible = false;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(618, 282);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(15, 15);
            this.button64.TabIndex = 65;
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Visible = false;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(567, 281);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(15, 15);
            this.button65.TabIndex = 66;
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Visible = false;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(376, 281);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(15, 15);
            this.button66.TabIndex = 67;
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Visible = false;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(289, 281);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(15, 15);
            this.button67.TabIndex = 68;
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Visible = false;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(226, 281);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(15, 15);
            this.button68.TabIndex = 69;
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Visible = false;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(188, 281);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(15, 15);
            this.button69.TabIndex = 70;
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Visible = false;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(165, 285);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(15, 15);
            this.button70.TabIndex = 71;
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Visible = false;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(157, 303);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(15, 15);
            this.button71.TabIndex = 72;
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Visible = false;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(177, 322);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(15, 15);
            this.button72.TabIndex = 73;
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Visible = false;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(245, 323);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(15, 15);
            this.button73.TabIndex = 74;
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Visible = false;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(315, 323);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(15, 15);
            this.button74.TabIndex = 75;
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Visible = false;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(337, 323);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(15, 15);
            this.button75.TabIndex = 76;
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Visible = false;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(415, 323);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(15, 15);
            this.button76.TabIndex = 77;
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Visible = false;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(452, 323);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(15, 15);
            this.button77.TabIndex = 78;
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Visible = false;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(510, 323);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(15, 15);
            this.button78.TabIndex = 79;
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Visible = false;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(623, 323);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(15, 15);
            this.button79.TabIndex = 80;
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Visible = false;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(745, 325);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(15, 15);
            this.button80.TabIndex = 81;
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Visible = false;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(761, 354);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(15, 15);
            this.button81.TabIndex = 82;
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Visible = false;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(729, 367);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(15, 15);
            this.button82.TabIndex = 83;
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Visible = false;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(670, 367);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(15, 15);
            this.button83.TabIndex = 84;
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Visible = false;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(642, 367);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(15, 15);
            this.button84.TabIndex = 85;
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Visible = false;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(488, 367);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(15, 15);
            this.button85.TabIndex = 86;
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Visible = false;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(432, 366);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(15, 15);
            this.button86.TabIndex = 87;
            this.button86.UseVisualStyleBackColor = true;
            this.button86.Visible = false;
            this.button86.Click += new System.EventHandler(this.button86_Click);
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(344, 365);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(15, 15);
            this.button87.TabIndex = 88;
            this.button87.UseVisualStyleBackColor = true;
            this.button87.Visible = false;
            this.button87.Click += new System.EventHandler(this.button87_Click);
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(218, 365);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(15, 15);
            this.button88.TabIndex = 89;
            this.button88.UseVisualStyleBackColor = true;
            this.button88.Visible = false;
            this.button88.Click += new System.EventHandler(this.button88_Click);
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(201, 365);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(15, 15);
            this.button89.TabIndex = 90;
            this.button89.UseVisualStyleBackColor = true;
            this.button89.Visible = false;
            this.button89.Click += new System.EventHandler(this.button89_Click);
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(156, 385);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(15, 15);
            this.button90.TabIndex = 91;
            this.button90.UseVisualStyleBackColor = true;
            this.button90.Visible = false;
            this.button90.Click += new System.EventHandler(this.button90_Click);
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(172, 406);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(15, 15);
            this.button91.TabIndex = 92;
            this.button91.UseVisualStyleBackColor = true;
            this.button91.Visible = false;
            this.button91.Click += new System.EventHandler(this.button91_Click);
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(195, 408);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(15, 15);
            this.button92.TabIndex = 93;
            this.button92.UseVisualStyleBackColor = true;
            this.button92.Visible = false;
            this.button92.Click += new System.EventHandler(this.button92_Click);
            // 
            // button93
            // 
            this.button93.Location = new System.Drawing.Point(239, 409);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(15, 15);
            this.button93.TabIndex = 94;
            this.button93.UseVisualStyleBackColor = true;
            this.button93.Visible = false;
            this.button93.Click += new System.EventHandler(this.button93_Click);
            // 
            // button94
            // 
            this.button94.Location = new System.Drawing.Point(302, 408);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(15, 15);
            this.button94.TabIndex = 95;
            this.button94.UseVisualStyleBackColor = true;
            this.button94.Visible = false;
            this.button94.Click += new System.EventHandler(this.button94_Click);
            // 
            // button95
            // 
            this.button95.Location = new System.Drawing.Point(409, 409);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(15, 15);
            this.button95.TabIndex = 96;
            this.button95.UseVisualStyleBackColor = true;
            this.button95.Visible = false;
            this.button95.Click += new System.EventHandler(this.button95_Click);
            // 
            // button96
            // 
            this.button96.Location = new System.Drawing.Point(468, 408);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(15, 15);
            this.button96.TabIndex = 97;
            this.button96.UseVisualStyleBackColor = true;
            this.button96.Visible = false;
            this.button96.Click += new System.EventHandler(this.button96_Click);
            // 
            // button97
            // 
            this.button97.Location = new System.Drawing.Point(594, 409);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(15, 15);
            this.button97.TabIndex = 98;
            this.button97.UseVisualStyleBackColor = true;
            this.button97.Visible = false;
            this.button97.Click += new System.EventHandler(this.button97_Click);
            // 
            // button98
            // 
            this.button98.Location = new System.Drawing.Point(619, 409);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(15, 15);
            this.button98.TabIndex = 99;
            this.button98.UseVisualStyleBackColor = true;
            this.button98.Visible = false;
            this.button98.Click += new System.EventHandler(this.button98_Click);
            // 
            // button99
            // 
            this.button99.Location = new System.Drawing.Point(687, 409);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(15, 15);
            this.button99.TabIndex = 100;
            this.button99.UseVisualStyleBackColor = true;
            this.button99.Visible = false;
            this.button99.Click += new System.EventHandler(this.button99_Click);
            // 
            // button100
            // 
            this.button100.Location = new System.Drawing.Point(761, 409);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(15, 15);
            this.button100.TabIndex = 101;
            this.button100.UseVisualStyleBackColor = true;
            this.button100.Visible = false;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 102;
            this.label1.Text = "Счет:";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 103;
            this.label2.Text = "Время:";
            // 
            // PlayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.glavnoeMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PlayForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Твердая ли у вас рука?";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button glavnoeMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
    }
}