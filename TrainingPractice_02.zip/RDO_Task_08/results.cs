﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RDO_Task_08
{
    public partial class results : Form
    {
        public results()
        {
            InitializeComponent();
        }

        //Переход на MainForm
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }

        //Очистка таблиц с результатами(ОЧИСТКА listBox ПРОИЗВОДИТСЯ ВМЕСТЕ С ОЧИСКОЙ ФАЙЛА!!!)
        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            File.WriteAllText("name.txt", string.Empty);
            File.WriteAllText("result.txt", string.Empty);
        }

        //Обновление информации в listbox'ах
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            using (OpenFileDialog List = new OpenFileDialog())
            {
                listBox1.Items.AddRange(File.ReadAllLines("name.txt"));
            }
            using (OpenFileDialog List2 = new OpenFileDialog())
            {
                listBox2.Items.AddRange(File.ReadAllLines("result.txt"));
            }
        }
    }
}
