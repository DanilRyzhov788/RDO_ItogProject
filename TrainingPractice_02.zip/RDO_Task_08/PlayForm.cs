﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RDO_Task_08
{
    public partial class PlayForm : Form
    {
        public int schet = 0;
        public int time = 0;
        public PlayForm()
        {
            InitializeComponent();
            timer1.Interval = 1000; //Установка интервала тика секундомера(1сек)
            timer1.Enabled = false; //Таймер не работает при объявлении формы
        }

        //Открытие MainForm до запуска игры или во время игры
        private void button1_Click(object sender, EventArgs e)
        {
            //Запись в текстовый файл значения набранных очков
            TextWriter sw = new StreamWriter("result.txt", true);
            sw.WriteLine(schet);
            sw.Close();

            //Открытие MainForm
            this.Close();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (time < 30)              //Ограничение по времени = 30сек
            {
                time++;

                //Вывод секундомера на экран
                label2.Text = "Время: " + time;
            }
            else
            {
                timer1.Enabled = false;  //Когда время закончилось(=  >30сек)
                //Вывод результата пользователя в MessageBox
                if (schet < 50)
                {
                    MessageBox.Show("Время вышло\nВаши очки: " + schet + "\nСлабовато, попробуйте еще раз");
                }
                if (schet >=50 && schet < 75)
                {
                    MessageBox.Show("Время вышло\nВаши очки: " + schet + "\nХороший результат, но есть к чему стремиться");
                }
                if (schet >= 75)
                {
                    MessageBox.Show("Время вышло\nВаши очки: " + schet + "\nОтличный результат!");
                }

                //Запись счета в файл 
                TextWriter sw = new StreamWriter("result.txt", true);
                sw.WriteLine(schet);
                sw.Close();
                //Закрытие PlayForm
                this.Close();
                MainForm mainForm = new MainForm();
                mainForm.Show();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //Включаем таймер по нажатию на первую кнопку
            timer1.Enabled = true;
            //Дальше повторяется на множестве кнопок
            schet++;                            //Очки +1
            label1.Text = "Счет: " + schet;     //Вывод очков на экран
            button1.Visible = false;            //Скрытие кнопки, на которую нажали
            button2.Visible = true;             //Показ следующей кнопки
        }

        private void button2_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button2.Visible = false;
            button3.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button3.Visible = false;
            button4.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button4.Visible = false;
            button5.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button5.Visible = false;
            button6.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button6.Visible = false;
            button7.Visible = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button7.Visible = false;
            button8.Visible = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button8.Visible = false;
            button9.Visible = true;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button9.Visible = false;
            button10.Visible = true;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button10.Visible = false;
            button11.Visible = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button11.Visible = false;
            button12.Visible = true;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button12.Visible = false;
            button13.Visible = true;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button13.Visible = false;
            button14.Visible = true;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button14.Visible = false;
            button15.Visible = true;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button15.Visible = false;
            button16.Visible = true;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button16.Visible = false;
            button17.Visible = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button17.Visible = false;
            button18.Visible = true;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button18.Visible = false;
            button19.Visible = true;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button19.Visible = false;
            button20.Visible = true;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button20.Visible = false;
            button21.Visible = true;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button21.Visible = false;
            button22.Visible = true;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button22.Visible = false;
            button23.Visible = true;
        }

        private void button23_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button23.Visible = false;
            button24.Visible = true;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button24.Visible = false;
            button25.Visible = true;
        }

        private void button25_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button25.Visible = false;
            button26.Visible = true;
        }

        private void button26_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button26.Visible = false;
            button27.Visible = true;
        }

        private void button27_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button27.Visible = false;
            button28.Visible = true;
        }

        private void button28_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button28.Visible = false;
            button29.Visible = true;
        }

        private void button29_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button29.Visible = false;
            button30.Visible = true;
        }

        private void button30_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button30.Visible = false;
            button31.Visible = true;
        }

        private void button31_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button31.Visible = false;
            button32.Visible = true;
        }

        private void button32_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button32.Visible = false;
            button33.Visible = true;
        }

        private void button33_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button33.Visible = false;
            button34.Visible = true;
        }

        private void button34_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button34.Visible = false;
            button35.Visible = true;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button35.Visible = false;
            button36.Visible = true;
        }

        private void button36_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button36.Visible = false;
            button37.Visible = true;
        }

        private void button37_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button37.Visible = false;
            button38.Visible = true;
        }

        private void button38_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button38.Visible = false;
            button39.Visible = true;
        }

        private void button39_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button39.Visible = false;
            button40.Visible = true;
        }

        private void button40_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button40.Visible = false;
            button41.Visible = true;
        }

        private void button41_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button41.Visible = false;
            button42.Visible = true;
        }

        private void button42_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button42.Visible = false;
            button43.Visible = true;
        }

        private void button43_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button43.Visible = false;
            button44.Visible = true;
        }

        private void button44_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button44.Visible = false;
            button45.Visible = true;
        }

        private void button45_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button45.Visible = false;
            button46.Visible = true;
        }

        private void button46_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button46.Visible = false;
            button47.Visible = true;
        }

        private void button47_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button47.Visible = false;
            button48.Visible = true;
        }

        private void button48_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button48.Visible = false;
            button49.Visible = true;
        }

        private void button49_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button49.Visible = false;
            button50.Visible = true;
        }

        private void button50_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button50.Visible = false;
            button51.Visible = true;
        }

        private void button51_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button51.Visible = false;
            button52.Visible = true;
        }

        private void button52_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button52.Visible = false;
            button53.Visible = true;
        }

        private void button53_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button53.Visible = false;
            button54.Visible = true;
        }

        private void button54_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button54.Visible = false;
            button55.Visible = true;
        }

        private void button55_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button55.Visible = false;
            button56.Visible = true;
        }

        private void button56_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button56.Visible = false;
            button57.Visible = true;
        }

        private void button57_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button57.Visible = false;
            button58.Visible = true;
        }

        private void button58_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button58.Visible = false;
            button59.Visible = true;
        }

        private void button59_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button59.Visible = false;
            button60.Visible = true;
        }

        private void button60_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button60.Visible = false;
            button61.Visible = true;
        }

        private void button61_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button61.Visible = false;
            button62.Visible = true;
        }

        private void button62_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button62.Visible = false;
            button63.Visible = true;
        }

        private void button63_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button63.Visible = false;
            button64.Visible = true;
        }

        private void button64_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button64.Visible = false;
            button65.Visible = true;
        }

        private void button65_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button65.Visible = false;
            button66.Visible = true;
        }

        private void button66_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button66.Visible = false;
            button67.Visible = true;
        }

        private void button67_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button67.Visible = false;
            button68.Visible = true;
        }

        private void button68_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button68.Visible = false;
            button69.Visible = true;
        }

        private void button69_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button69.Visible = false;
            button70.Visible = true;
        }

        private void button70_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button70.Visible = false;
            button71.Visible = true;
        }

        private void button71_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button71.Visible = false;
            button72.Visible = true;
        }

        private void button72_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button72.Visible = false;
            button73.Visible = true;
        }

        private void button73_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button73.Visible = false;
            button74.Visible = true;
        }

        private void button74_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button74.Visible = false;
            button75.Visible = true;
        }

        private void button75_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button75.Visible = false;
            button76.Visible = true;
        }

        private void button76_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button76.Visible = false;
            button77.Visible = true;
        }

        private void button77_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button77.Visible = false;
            button78.Visible = true;
        }

        private void button78_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button78.Visible = false;
            button79.Visible = true;
        }

        private void button79_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button79.Visible = false;
            button80.Visible = true;
        }

        private void button80_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button80.Visible = false;
            button81.Visible = true;
        }

        private void button81_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button81.Visible = false;
            button82.Visible = true;
        }

        private void button82_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button82.Visible = false;
            button83.Visible = true;
        }

        private void button83_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button83.Visible = false;
            button84.Visible = true;
        }

        private void button84_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button84.Visible = false;
            button85.Visible = true;
        }

        private void button85_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button85.Visible = false;
            button86.Visible = true;
        }

        private void button86_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button86.Visible = false;
            button87.Visible = true;
        }

        private void button87_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button87.Visible = false;
            button88.Visible = true;
        }

        private void button88_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button88.Visible = false;
            button89.Visible = true;
        }

        private void button89_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button89.Visible = false;
            button90.Visible = true;
        }

        private void button90_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button90.Visible = false;
            button91.Visible = true;
        }

        private void button91_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button91.Visible = false;
            button92.Visible = true;
        }

        private void button92_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button92.Visible = false;
            button93.Visible = true;
        }

        private void button93_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button93.Visible = false;
            button94.Visible = true;
        }

        private void button94_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button94.Visible = false;
            button95.Visible = true;
        }

        private void button95_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button95.Visible = false;
            button96.Visible = true;
        }

        private void button96_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button96.Visible = false;
            button97.Visible = true;
        }

        private void button97_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button97.Visible = false;
            button98.Visible = true;
        }

        private void button98_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button98.Visible = false;
            button99.Visible = true;
        }

        private void button99_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button99.Visible = false;
            button100.Visible = true;
        }

        private void button100_Click(object sender, EventArgs e)
        {
            schet++;
            label1.Text = "Счет: " + schet;
            button100.Visible = false;
            MessageBox.Show("Вы выиграли!!!");      //Вывод сообщения в MessageBox при условии набора 100 очков(у меня так и не вышло)
        }
    }
}
